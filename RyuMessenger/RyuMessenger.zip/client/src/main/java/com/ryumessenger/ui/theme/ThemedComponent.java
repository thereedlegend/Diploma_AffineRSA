package com.ryumessenger.ui.theme;

public interface ThemedComponent {
    void applyTheme();
} 