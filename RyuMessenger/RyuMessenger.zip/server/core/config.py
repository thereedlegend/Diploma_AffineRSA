# Server configuration settings
DEBUG = True
SECRET_KEY = 'your_very_secret_flask_key' # Важно изменить для продакшена 